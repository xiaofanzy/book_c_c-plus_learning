#include <stdio.h>

int main(void)
{
    printf("zhang yu\n");
    printf("zhang\nyu\n");
    printf("zhang ");
    printf("yu\n");

    return 0;
}