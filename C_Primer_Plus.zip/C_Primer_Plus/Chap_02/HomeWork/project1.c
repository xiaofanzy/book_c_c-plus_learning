#include <stdio.h>

int main(void)
{
    printf("My name is zhangyu and my Address is ....");

    return 0;
}