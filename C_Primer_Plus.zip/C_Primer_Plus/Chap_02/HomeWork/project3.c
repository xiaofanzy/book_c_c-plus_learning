#include <stdio.h>

int main(void)
{
    printf("Enter your age : 29");

    return 0;
}