#include <stdio.h>

void my_function1();
void my_function2();

int main(void)
{
    my_function1();
    my_function2();

    return 0;
}

void my_function1(void)
{
    printf("")
}