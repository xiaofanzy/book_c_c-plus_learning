#include <stdio.h>

int main(void)
{
    int years, days;
    years = 35;
    days = years * 365;

    printf(" The %d years is %d days.\n", years, days);

    return 0;
}