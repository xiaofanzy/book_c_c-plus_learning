// 操作系统调用了main函数
#include <stdio.h>

/* 最简单的C程序 */
int main(void) // void main
{
    int num;
    num = 1;

    printf("Hello World\n");
    printf("my favorite num is %d\n", num);

    return 0;
}