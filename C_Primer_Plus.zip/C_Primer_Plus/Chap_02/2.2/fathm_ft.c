/* 英寸英尺转换 */
#include <stdio.h>

int main(void)
{

    int feet, fathmod;
    fathmod = 2;
    feet = 6 * fathmod;

    printf("the %d feet = %d fathmod \n", feet, fathmod);
    printf("Yes i sad %d feet.\n", feet);

    return 0;
}