#include <stdio.h>

void answer(void);

int main(void)
{
    printf("Rick what's you doing now ? \n");
    answer();
    printf("OK, Come here, i need you help.\n");

    return 0;
}

void answer(void)
{
    printf("Dad I'm watching TV Now. \n");
}