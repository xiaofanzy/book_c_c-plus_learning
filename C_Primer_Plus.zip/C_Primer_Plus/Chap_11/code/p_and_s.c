#include <stdio.h>

int main(void)
{
    char *meag = "Don't be a fool!";
    char *copy;

    copy = meag;
    printf("meag = %s &meag = %p, value = %p\n", meag, &meag, meag);
    printf("copy = %s &copy = %p, value = %p\n", copy, &copy, copy);

        paramsIn.put("id", CommUtil.getString(maps.get("id")));
		
        






    return 0;
}