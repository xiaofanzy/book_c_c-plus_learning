#include <stdio.h>
#define MSG "You must be have many talents. Tell me some."
#define LIM 5
#define LINELEN 81

int main(void)
{

    return 0;
}

%CPU  Subsystem 98.8  <Process total CPU usage> 25.6  progress (in com.intellij.openapi) 7.0  webSymbols.inspections (in com.intellij) 4.6  codeInsight.daemon.impl (in com.intellij) 4.6  jdk.internal.misc 4.6  Plugin Java: psi.util (in com.intellij) 3.9  editor.impl (in com.intellij.openapi) 3.1  Plugin Java: uast.java (in org.jetbrains)