#include <stdio.h>

int main(void)
{
    printf("%s %p %c", "We", "are", *"the family");

    return 0;
}
