#include <stdio.h>

int main(void)
{
    printf("Integer division 5/4 is %d\n", 5 / 4);
    printf("Integer division 8/4 is %d\n", 8 / 4);
    printf("Integer division 7/4 is %d\n", 7 / 4);
    printf("floating division 7.0/4.0 is %.2f\n", 7.0 / 4.0);
    printf("floating division 5/4 is %.2f\n", 5.0 / 4);

    return 0;
}