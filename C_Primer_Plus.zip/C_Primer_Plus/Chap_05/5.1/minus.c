#include <stdio.h>

int main(void)
{
    printf("11 / -5 is %d and 11%-2 is %d", 11 / -5, 11 % -2);

    return 0;
}