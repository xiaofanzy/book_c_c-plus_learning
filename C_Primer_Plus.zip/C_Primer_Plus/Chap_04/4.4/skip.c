#include <stdio.h>

int main(void)
{
    int n;

    scanf("%*d %*d %d", &n);
    printf("%d", n);

    return 0;
}