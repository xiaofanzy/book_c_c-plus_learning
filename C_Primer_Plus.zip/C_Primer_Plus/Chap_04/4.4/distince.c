#include <stdio.h>

int main(void)
{
    printf("%9d%9d%9d\n", 1, 2, 3);
    printf("%9d%9d%9d\n", 10, 20, 30);
    printf("%9d%9d%9d\n", 100, 200, 300);

    return 0;
}