#include <stdio.h>
#define PAGES 931

int main(void)
{
    printf("*%d*\n, *%2d*\n, *%10d*\n, *%-10d*\n", PAGES, PAGES, PAGES, PAGES);

    return 0;
}