#include <stdio.h>

int main(void)
{
    int i = printf("hello world!\n");
    printf("i = %d", i);

    return 0;
}