#define HOTEL1 80.00
#define HOTEL2 125.00
#define HOTEL3 155.00
#define HOTEL4 200.00
#define QUIT 5
#define DISTINCT 0.95
#define STARS "********************************"

int menu(void);

int getnights(void);

void showprice(double hotel_rate, int nights);