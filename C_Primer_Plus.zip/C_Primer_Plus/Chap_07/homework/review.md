# 001
1. false;
2. true;
3. false;

# 002
1. number >= 90 && number < 100
2. ch != 'q' && ch != 'k'
3. number < 9 && number > 1 && number != 5
4. number >9 || number < 1

# 003
```
#include<stdio.h>

int main(void)
{
    int wegiht,height;

    scanf("%d%d" &weight, &height);

    if(weight < 100 && height > 64)
    {
        if(height >= 72)
            printf("You are very tall for your weight.\n");
        else 
            printf("your are tall for your weight\n");
    }
    else if(weight > 300 && height < 48 )
    {
            printf("Your are quite short for your weight.\n");
    }
    else
        print("You weight is ideal.\n");

    return 0;
}

```

# 004
a. true
b. false;
c. 1;
d. 6
e. 10
f. false;

# 005
*#%*#%$%*#%*#%$%*#%*#%$%%*#%*#%

# 006
fathatcatonno!
hatcatonno!
catonno!

